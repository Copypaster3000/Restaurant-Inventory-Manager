# Restaurant Inventory Tracking System
This program helps you track the food in your restaurant and how often each food item needs to be ordered.
When you run the program it will give you a more detailed explanation of it's purpose and features. 


## Getting setup
You likely received this project as a zip file. To run the program, upload it to your Linux environment 
or the system you will be running it on. Then unzip the file.


## Running the program
This program comes with a makefile that does all of the compilation work for you. To compile the program enter "make this_prog"
into your terminal. Then to run it type "./this_prog".


## Using the program
Once you run the program it will give you a list of menu options. You can select an option by entering an integer into the 
terminal. The program will explain each step and prompt you for any information it needs. 
