//error.h
//Drake Wheeler
//Program 3
//CS302
//Karla Fant
//7/30/2024
//This is the header file for the error structs used in the restaurant inventory tracking system.
//It defines the over_write and missing_data structs, which are used to handle specific error
//conditions related to overwriting existing data and missing data. These structs include a string 
//detail that provides a description of the error.


#ifndef ERROR_H
#define ERROR_H

#include <string>

struct over_write
{
	string detail = "\nWARNING. Some data was over written.";
};


struct missing_data
{
	string detail = "\nERROR. Data that was used for something was missing.";
};


#endif // ERROR_H
